/* quando a página abrir */

window.onload = function(){

let cpf = localStorage.getItem("cpfUsuario")

document.getElementById("cpf").value = cpf

}


/* salvar senha */

function salvarSenha(){

let senha = document.getElementById("senha").value
let confirmar = document.getElementById("confirmar").value
let erro = document.getElementById("erro")

if(senha.length < 6){
erro.innerText = "A senha precisa ter pelo menos 6 caracteres"
return
}

if(senha !== confirmar){
erro.innerText = "As senhas não coincidem"
return
}

erro.innerText = ""

alert("Senha criada com sucesso!")

window.location.href = "dashboard-viajante.html"

}