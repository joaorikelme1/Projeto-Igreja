function login(){

let cpf = document.getElementById("cpf").value
let senha = document.getElementById("senha").value

/* salva cpf no navegador */
localStorage.setItem("cpfUsuario", cpf)

/* ADMIN */

if(cpf === "admin" && senha === "admin123"){
window.location.href = "dashboard-admin.html"
return
}

/* PRIMEIRO ACESSO */

if(senha === "acess@123"){
window.location.href = "primeiro-acesso.html"
return
}

/* LOGIN NORMAL */

if(cpf === "12345678900"){
window.location.href = "dashboard-viajante.html"
return
}

alert("CPF ou senha incorretos")

}