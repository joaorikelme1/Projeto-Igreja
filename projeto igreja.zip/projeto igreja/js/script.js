function login(){

let cpf=document.getElementById("cpf").value
let senha=document.getElementById("senha").value

if(senha==="acess@123"){
    alert("Primeiro acesso. Crie uma nova senha.")
}

if(cpf==="admin"){
    window.location="dashboard-admin.html"
}else{
    window.location="dashboard-viajante.html"
}

}

function abrirPopup(id){
document.getElementById(id).style.display="flex"
}

function fecharPopup(id){
document.getElementById(id).style.display="none"
}